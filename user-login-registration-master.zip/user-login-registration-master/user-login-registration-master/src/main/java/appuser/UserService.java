package appuser;
import java.util.List;
import java.util.Optional;

public interface UserService {
    
    // Save a new user
    User saveUser(User user);
    
    // Get a user by their ID
    Optional<User> getUserById(Long id);
    
    // Get all users
    List<User> getAllUsers();
    
    // Update an existing user
    User updateUser(Long id, User user);
    
    // Delete a user
    void deleteUser(Long id);
    
    
}
